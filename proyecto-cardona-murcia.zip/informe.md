# Informe · Q1 / fila 3 · Arquitectura hexagonal

## Medición (`git diff --name-status hoja-1 final`)

| Medida | Resultado |
|---|---|
| Archivos creados | 2: `adapter/in/cli/MuestraHoja2Runner.java` y `PoliticaDescuentoTramoTest.java` |
| Archivos modificados | 2: `LEEME.md` y `domain/model/PoliticaDescuento.java` |
| ¿Se modificó el archivo o la clase que calcula el total? | Sí: `PoliticaDescuento.java` |
| ¿Se modificó el archivo o la clase que registra el pedido? | No: `PedidoUseCaseService.java` no aparece en el diff |
| ¿Se tocó una prueba de la Hoja 1? | No: `PoliticaDescuentoTest` y `PedidoUseCaseServiceTest` no aparecen en el diff |

## Preguntas

**Primera: predicción contra medición.** El ADR-0001 predijo modificar un solo archivo de producción, `PoliticaDescuento.java`, más `LEEME.md`, crear `MuestraHoja2Runner.java` y `PoliticaDescuentoTramoTest.java`, y no tocar `PedidoUseCaseService` ni las pruebas de la Hoja 1. La tabla midió 2 archivos creados y 2 modificados con exactamente esos nombres, de modo que la predicción acertó, incluidos los tres "no". Que coincida no se debe a haberla escrito después: el commit del ADR-0001 es anterior a la etiqueta `hoja-1`, como lo muestra el `git log` de `evidencia.txt`. Lo que no pudimos comprobar fue otra pérdida del mismo ADR, los 17 archivos nuevos, porque el punto de partida y la Hoja 1 entraron en un solo commit y ese diff no existe.

**Segunda: el límite.** Si la tienda agrega reacciones a cada pedido confirmado, como emitir una factura y avisar al cliente, la hexagonal sería peor que eventos. Cada reacción obligaría a editar `PedidoUseCaseService`, la clase que registra el pedido, y habría que cuidar a mano que un fallo de facturación no deje el pedido sin registrar. En eventos basta agregar un suscriptor sin tocar el registro. La guía de eventos dice que las llamadas normales alcanzan cuando hay un solo consumidor y no habrá más, y aquí habría varios; y la sección de desventajas de la guía hexagonal admite que sus fronteras dependen de la disciplina y no de la estructura.

**Tercera: lo que la regla no ve.** La violación inducida fue agregar `import jakarta.persistence.Entity;` en `domain/model/Pedido.java`: el `grep` la detectó en la línea 2 y se revirtió con `git checkout` sin hacer commit, según `evidencia.txt`. En cambio, la regla no detectaría que una clase de `domain` importe `ProductJpaEntity` del adaptador de persistencia. El primer `grep` busca solo `org.springframework` y `jakarta` bajo `domain`, y el segundo revisa únicamente `application`, así que ninguno mira ese import. Cerrar el hueco exigiría buscar también `import com.ejemplo.catalogo.adapter` bajo `domain`.
