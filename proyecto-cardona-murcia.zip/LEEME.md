# LEEME · Proyecto en pareja (Q1 / fila 3, arquitectura hexagonal)

Requisitos: Java 21 y Maven (`mvn`). La persistencia es H2 en memoria: cada arranque parte de una base vacía.

## Muestra de la Hoja 1
Desde la carpeta `codigo/`:

```
cd codigo
mvn -q spring-boot:run "-Dspring-boot.run.arguments=--muestra=hoja1 --spring.main.web-application-type=none"
```

Salida esperada (fila 3):

```
PEDIDO 1 CONFIRMADO total=1200000
PEDIDO 2 CONFIRMADO total=1584000
PEDIDO 3 RECHAZADO total=0
PEDIDO 4 CONFIRMADO total=10032000
```

Esta es la salida sobre la etiqueta `hoja-1`. Con el tramo nuevo de la Hoja 2 (Q1) solo cambia la línea 4, como dice la Hoja 2: la cantidad 19 recibe d + 5 y el total pasa a `9462000`.

## Muestra de la Hoja 2
Desde la carpeta `codigo/`:

```
cd codigo
mvn -q spring-boot:run "-Dspring-boot.run.arguments=--muestra=hoja2 --spring.main.web-application-type=none"
```

Salida esperada (fila 3):

```
PEDIDO 1 CONFIRMADO total=4482000
PEDIDO 2 CONFIRMADO total=4224000
PEDIDO 3 CONFIRMADO total=600000
```

## Pruebas
```
cd codigo
mvn test
```

## Regla de arquitectura (hexagonal)
Desde la raíz del proyecto, ambos comandos no deben imprimir nada:

```
grep -rn "import org.springframework\|import jakarta" codigo/src/main/java/com/ejemplo/catalogo/domain
grep -rn "import com.ejemplo.catalogo.adapter" codigo/src/main/java/com/ejemplo/catalogo/application
```

Si alguno imprime líneas, la regla de dependencia está rota.
