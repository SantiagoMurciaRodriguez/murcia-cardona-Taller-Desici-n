package com.ejemplo.catalogo.adapter.in.web.dto;

public record PedidoResponse(
        Long id,
        String clienteId,
        Long productoId,
        int cantidad,
        String estado,
        long total
) {
}
