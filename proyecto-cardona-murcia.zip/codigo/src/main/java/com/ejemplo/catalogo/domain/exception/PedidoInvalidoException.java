package com.ejemplo.catalogo.domain.exception;

/** RN-5: error de validacion. No es un pedido RECHAZADO: no se registra ni consume id. */
public class PedidoInvalidoException extends RuntimeException {
    public PedidoInvalidoException(String mensaje) {
        super(mensaje);
    }
}
