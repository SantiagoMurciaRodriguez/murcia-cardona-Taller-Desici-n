package com.ejemplo.catalogo.domain.port.in;

import com.ejemplo.catalogo.domain.model.Pedido;

/** Puerto de entrada: lo que la aplicacion ofrece sobre pedidos. */
public interface PedidoService {

    /** Registra un pedido: CONFIRMADO o RECHAZADO (RN-3). Lanza PedidoInvalidoException (RN-5). */
    Pedido registrar(String clienteId, Long productoId, int cantidad);

    /** RN-4: consulta por id. */
    Pedido consultar(Long id);

    /** RN-4: suma de los total de los pedidos CONFIRMADO del cliente. */
    long totalComprado(String clienteId);
}
