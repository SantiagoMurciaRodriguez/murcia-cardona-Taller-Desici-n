package com.ejemplo.catalogo.domain.model;

public enum EstadoPedido {
    CONFIRMADO,
    RECHAZADO
}
