package com.ejemplo.catalogo.adapter.in.cli;

import com.ejemplo.catalogo.domain.model.Pedido;
import com.ejemplo.catalogo.domain.model.PoliticaDescuento;
import com.ejemplo.catalogo.domain.port.in.PedidoService;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/** Muestra de la Hoja 2 (Q1): el tramo nuevo, cantidad >= 3u => d + 5 puntos. Fila 3. */
@Component
@Order(1)
@ConditionalOnProperty(name = "muestra", havingValue = "hoja2")
public class MuestraHoja2Runner implements ApplicationRunner {

    private final PedidoService service;
    private final ConfigurableApplicationContext context;

    public MuestraHoja2Runner(PedidoService service, ConfigurableApplicationContext context) {
        this.service = service;
        this.context = context;
    }

    @Override
    public void run(ApplicationArguments args) {
        int u = PoliticaDescuento.UMBRAL;
        imprimir(service.registrar("C-001", 1L, 3 * u));
        imprimir(service.registrar("C-002", 1L, 3 * u - 1));
        imprimir(service.registrar("C-003", 1L, 1));
        SpringApplication.exit(context, () -> 0);
    }

    private void imprimir(Pedido p) {
        System.out.println("PEDIDO " + p.getId() + " " + p.getEstado() + " total=" + p.getTotal());
    }
}
