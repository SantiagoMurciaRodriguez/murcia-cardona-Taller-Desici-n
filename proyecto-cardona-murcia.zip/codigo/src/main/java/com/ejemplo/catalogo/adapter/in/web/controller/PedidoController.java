package com.ejemplo.catalogo.adapter.in.web.controller;

import com.ejemplo.catalogo.adapter.in.web.dto.PedidoRequest;
import com.ejemplo.catalogo.adapter.in.web.dto.PedidoResponse;
import com.ejemplo.catalogo.adapter.in.web.mapper.PedidoMapper;
import com.ejemplo.catalogo.domain.port.in.PedidoService;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PedidoController {

    private final PedidoService service;

    public PedidoController(PedidoService service) {
        this.service = service;
    }

    // POST /api/pedidos -> 201 (CONFIRMADO o RECHAZADO), 400 si RN-5
    @PostMapping("/pedidos")
    public ResponseEntity<PedidoResponse> registrar(@Valid @RequestBody PedidoRequest request) {
        PedidoResponse response = PedidoMapper.toResponse(
                service.registrar(request.clienteId(), request.productoId(), request.cantidad()));
        return ResponseEntity.created(URI.create("/api/pedidos/" + response.id())).body(response);
    }

    @GetMapping("/pedidos/{id}")
    public PedidoResponse consultar(@PathVariable Long id) {
        return PedidoMapper.toResponse(service.consultar(id));
    }

    @GetMapping("/clientes/{clienteId}/total")
    public Map<String, Object> totalComprado(@PathVariable String clienteId) {
        return Map.of("clienteId", clienteId, "total", service.totalComprado(clienteId));
    }
}
