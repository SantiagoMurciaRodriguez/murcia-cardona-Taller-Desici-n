package com.ejemplo.catalogo.domain.port.in;

import com.ejemplo.catalogo.domain.model.Product;
import java.util.List;

/** Puerto de entrada: operaciones de producto, en terminos del dominio. */
public interface ProductService {

    List<Product> findAll(String q);

    Product findById(Long id);

    Product create(Product product);

    Product update(Long id, Product changes);

    void delete(Long id);
}
