package com.ejemplo.catalogo.application.usecase;

import com.ejemplo.catalogo.domain.exception.PedidoInvalidoException;
import com.ejemplo.catalogo.domain.exception.PedidoNoEncontradoException;
import com.ejemplo.catalogo.domain.model.EstadoPedido;
import com.ejemplo.catalogo.domain.model.Pedido;
import com.ejemplo.catalogo.domain.model.PoliticaDescuento;
import com.ejemplo.catalogo.domain.model.Product;
import com.ejemplo.catalogo.domain.port.in.PedidoService;
import com.ejemplo.catalogo.domain.port.out.PedidoRepository;
import com.ejemplo.catalogo.domain.port.out.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Registra pedidos. Depende solo de puertos de salida y del dominio. */
@Service
@Transactional(readOnly = true)
public class PedidoUseCaseService implements PedidoService {

    private final PedidoRepository pedidos;
    private final ProductRepository productos;

    public PedidoUseCaseService(PedidoRepository pedidos, ProductRepository productos) {
        this.pedidos = pedidos;
        this.productos = productos;
    }

    @Override
    @Transactional
    public Pedido registrar(String clienteId, Long productoId, int cantidad) {
        // RN-5: errores de validacion: no se registra nada y no se consume id
        if (cantidad <= 0) {
            throw new PedidoInvalidoException("La cantidad debe ser mayor que cero");
        }
        Product producto = productos.findById(productoId)
                .orElseThrow(() -> new PedidoInvalidoException(
                        "No existe el producto con id " + productoId));

        Pedido pedido;
        if (cantidad > producto.getStock()) {
            // RN-3: se pasaria del stock: RECHAZADO, total 0, no consume stock
            pedido = new Pedido(clienteId, productoId, cantidad, EstadoPedido.RECHAZADO, 0L);
        } else {
            long total = PoliticaDescuento.total(producto.getPrice().longValueExact(), cantidad);
            producto.setStock(producto.getStock() - cantidad);
            productos.save(producto);
            pedido = new Pedido(clienteId, productoId, cantidad, EstadoPedido.CONFIRMADO, total);
        }
        return pedidos.save(pedido); // todo pedido que pasa la validacion recibe id
    }

    @Override
    public Pedido consultar(Long id) {
        return pedidos.findById(id).orElseThrow(() -> new PedidoNoEncontradoException(id));
    }

    @Override
    public long totalComprado(String clienteId) {
        return pedidos.findByClienteId(clienteId).stream()
                .filter(p -> p.getEstado() == EstadoPedido.CONFIRMADO)
                .mapToLong(Pedido::getTotal)
                .sum();
    }
}
