package com.ejemplo.catalogo.domain.exception;

public class ProductNotFoundException extends RuntimeException {
    public ProductNotFoundException(Long id) {
        super("No existe el producto con id " + id);
    }
}
