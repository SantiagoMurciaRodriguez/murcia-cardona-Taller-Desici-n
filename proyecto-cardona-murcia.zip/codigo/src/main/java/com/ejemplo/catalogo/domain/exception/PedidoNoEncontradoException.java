package com.ejemplo.catalogo.domain.exception;

public class PedidoNoEncontradoException extends RuntimeException {
    public PedidoNoEncontradoException(Long id) {
        super("No existe el pedido con id " + id);
    }
}
