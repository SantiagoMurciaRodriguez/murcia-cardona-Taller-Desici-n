package com.ejemplo.catalogo.adapter.in.web.exception;

import com.ejemplo.catalogo.domain.exception.PedidoInvalidoException;
import com.ejemplo.catalogo.domain.exception.PedidoNoEncontradoException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/** Clase nueva: asi no se modifica GlobalExceptionHandler. */
@RestControllerAdvice
public class PedidoExceptionHandler {

    @ExceptionHandler(PedidoInvalidoException.class)
    public ProblemDetail handleInvalido(PedidoInvalidoException ex) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
        problem.setTitle("Pedido invalido");
        return problem;
    }

    @ExceptionHandler(PedidoNoEncontradoException.class)
    public ProblemDetail handleNoEncontrado(PedidoNoEncontradoException ex) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Pedido no encontrado");
        return problem;
    }
}
