package com.ejemplo.catalogo.domain.model;

/** Modelo de dominio puro: sin Spring ni JPA. */
public class Pedido {

    private Long id;
    private final String clienteId;
    private final Long productoId;
    private final int cantidad;
    private final EstadoPedido estado;
    private final long total;

    public Pedido(String clienteId, Long productoId, int cantidad,
                  EstadoPedido estado, long total) {
        this.clienteId = clienteId;
        this.productoId = productoId;
        this.cantidad = cantidad;
        this.estado = estado;
        this.total = total;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getClienteId() { return clienteId; }
    public Long getProductoId() { return productoId; }
    public int getCantidad() { return cantidad; }
    public EstadoPedido getEstado() { return estado; }
    public long getTotal() { return total; }
}
