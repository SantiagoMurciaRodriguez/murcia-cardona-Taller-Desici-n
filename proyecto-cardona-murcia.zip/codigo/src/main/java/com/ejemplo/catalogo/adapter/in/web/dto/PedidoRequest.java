package com.ejemplo.catalogo.adapter.in.web.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/** RN-5 (cantidad > 0, producto existente) se valida en el caso de uso, no aqui. */
public record PedidoRequest(
        @NotBlank(message = "El cliente es obligatorio") String clienteId,
        @NotNull(message = "El producto es obligatorio") Long productoId,
        @NotNull(message = "La cantidad es obligatoria") Integer cantidad
) {
}
