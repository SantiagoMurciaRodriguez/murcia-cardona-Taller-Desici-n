package com.ejemplo.catalogo.domain.model;

/**
 * RN-1 y RN-2 en una sola clase pura. Valores de la fila 3 (Monitor):
 * umbral u = 3 unidades, descuento d = 12 %.
 * Es el unico lugar donde vive la regla de descuento.
 */
public final class PoliticaDescuento {

    public static final int UMBRAL = 3;
    public static final int DESCUENTO = 12;
    /** Hoja 2 (Q1): tramo nuevo desde 3u unidades, con 5 puntos mas de descuento. */
    public static final int UMBRAL_TRAMO = 3 * UMBRAL;
    public static final int PUNTOS_TRAMO = 5;

    private PoliticaDescuento() {
    }

    /** RN-1: cantidad >= 3u, d + 5 %; cantidad >= u, d %; si no, 0 %. */
    public static int porcentaje(int cantidad) {
        if (cantidad >= UMBRAL_TRAMO) {
            return DESCUENTO + PUNTOS_TRAMO;
        }
        return cantidad >= UMBRAL ? DESCUENTO : 0;
    }

    /** RN-2: cantidad x precio x (100 - descuento) / 100, en pesos enteros. */
    public static long total(long precio, int cantidad) {
        return cantidad * precio * (100 - porcentaje(cantidad)) / 100;
    }
}
