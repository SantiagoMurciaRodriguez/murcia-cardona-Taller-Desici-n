package com.ejemplo.catalogo.adapter.in.web.mapper;

import com.ejemplo.catalogo.adapter.in.web.dto.PedidoResponse;
import com.ejemplo.catalogo.domain.model.Pedido;

public final class PedidoMapper {

    private PedidoMapper() {
    }

    public static PedidoResponse toResponse(Pedido p) {
        return new PedidoResponse(p.getId(), p.getClienteId(), p.getProductoId(),
                p.getCantidad(), p.getEstado().name(), p.getTotal());
    }
}
