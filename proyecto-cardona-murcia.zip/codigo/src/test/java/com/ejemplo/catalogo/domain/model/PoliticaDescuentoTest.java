package com.ejemplo.catalogo.domain.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/** RN-1 y RN-2 con la fila 3 (Monitor 600.000, u = 3, d = 12 %). */
class PoliticaDescuentoTest {

    @Test
    void sinDescuentoJustoPorDebajoDelUmbral() {
        assertThat(PoliticaDescuento.porcentaje(2)).isEqualTo(0);
        assertThat(PoliticaDescuento.total(600_000L, 2)).isEqualTo(1_200_000L);
    }

    @Test
    void elUmbralMismoYaTieneDescuento() {
        assertThat(PoliticaDescuento.porcentaje(3)).isEqualTo(12);
        assertThat(PoliticaDescuento.total(600_000L, 3)).isEqualTo(1_584_000L);
    }

    @Test
    void porEncimaDelUmbralSigueElMismoDescuento() {
        assertThat(PoliticaDescuento.porcentaje(8)).isEqualTo(12);
        assertThat(PoliticaDescuento.total(600_000L, 8)).isEqualTo(4_224_000L);
    }
}
