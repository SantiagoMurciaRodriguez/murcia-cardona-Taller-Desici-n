package com.ejemplo.catalogo.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ejemplo.catalogo.domain.exception.PedidoInvalidoException;
import com.ejemplo.catalogo.domain.model.EstadoPedido;
import com.ejemplo.catalogo.domain.model.Pedido;
import com.ejemplo.catalogo.domain.model.Product;
import com.ejemplo.catalogo.domain.port.out.PedidoRepository;
import com.ejemplo.catalogo.domain.port.out.ProductRepository;
import java.math.BigDecimal;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** RN-3 (stock) y RN-5 (validacion) con la fila 3: stock 24. */
@ExtendWith(MockitoExtension.class)
class PedidoUseCaseServiceTest {

    @Mock
    private PedidoRepository pedidos;
    @Mock
    private ProductRepository productos;
    @InjectMocks
    private PedidoUseCaseService service;

    private Product monitor() {
        Product p = new Product("Monitor", "Monitor", new BigDecimal("600000.00"), 24, "electronica");
        p.setId(1L);
        return p;
    }

    @Test
    void pedidoQueSePasaDelStockQuedaRechazadoYNoConsumeStock() {
        Product monitor = monitor();
        when(productos.findById(1L)).thenReturn(Optional.of(monitor));
        when(pedidos.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        Pedido pedido = service.registrar("C-001", 1L, 25);

        assertThat(pedido.getEstado()).isEqualTo(EstadoPedido.RECHAZADO);
        assertThat(pedido.getTotal()).isZero();
        assertThat(monitor.getStock()).isEqualTo(24);
        verify(productos, never()).save(any(Product.class));
    }

    @Test
    void pedidoQueDejaElStockEnCeroSeConfirma() {
        Product monitor = monitor();
        when(productos.findById(1L)).thenReturn(Optional.of(monitor));
        when(productos.save(any(Product.class))).thenAnswer(i -> i.getArgument(0));
        when(pedidos.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        Pedido pedido = service.registrar("C-001", 1L, 24);

        assertThat(pedido.getEstado()).isEqualTo(EstadoPedido.CONFIRMADO);
        assertThat(monitor.getStock()).isZero();
    }

    @Test
    void cantidadCeroEsErrorDeValidacionYNoSeRegistra() {
        assertThatThrownBy(() -> service.registrar("C-001", 1L, 0))
                .isInstanceOf(PedidoInvalidoException.class);
        verify(pedidos, never()).save(any(Pedido.class));
    }

    @Test
    void productoInexistenteEsErrorDeValidacionYNoSeRegistra() {
        when(productos.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.registrar("C-001", 99L, 1))
                .isInstanceOf(PedidoInvalidoException.class);
        verify(pedidos, never()).save(any(Pedido.class));
    }
}
