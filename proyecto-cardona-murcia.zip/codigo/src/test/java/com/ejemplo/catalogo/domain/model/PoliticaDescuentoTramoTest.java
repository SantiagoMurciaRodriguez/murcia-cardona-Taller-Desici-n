package com.ejemplo.catalogo.domain.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/** Hoja 2 (Q1): tramo nuevo, cantidad >= 3u => d + 5 puntos. Fila 3 (u = 3, d = 12 %). */
class PoliticaDescuentoTramoTest {

    @Test
    void justoPorDebajoDelTramoSigueEnD() {
        assertThat(PoliticaDescuento.porcentaje(8)).isEqualTo(12);
        assertThat(PoliticaDescuento.total(600_000L, 8)).isEqualTo(4_224_000L);
    }

    @Test
    void elTramoMismoYaTieneDMasCincoPuntos() {
        assertThat(PoliticaDescuento.porcentaje(9)).isEqualTo(17);
        assertThat(PoliticaDescuento.total(600_000L, 9)).isEqualTo(4_482_000L);
    }

    @Test
    void porEncimaDelTramoSigueElMismoDescuento() {
        assertThat(PoliticaDescuento.porcentaje(19)).isEqualTo(17);
        assertThat(PoliticaDescuento.total(600_000L, 19)).isEqualTo(9_462_000L);
    }
}
