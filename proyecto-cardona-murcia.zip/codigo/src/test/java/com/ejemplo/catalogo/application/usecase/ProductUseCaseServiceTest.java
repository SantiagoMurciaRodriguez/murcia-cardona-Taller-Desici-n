package com.ejemplo.catalogo.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ejemplo.catalogo.domain.exception.ProductNotFoundException;
import com.ejemplo.catalogo.domain.model.Product;
import com.ejemplo.catalogo.domain.port.out.ProductRepository;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ProductUseCaseServiceTest {

    @Mock
    private ProductRepository repository;

    @InjectMocks
    private ProductUseCaseService service;

    @Test
    void findAllWithoutFilterListsEverything() {
        when(repository.findAll()).thenReturn(List.of());

        assertThat(service.findAll(null)).isEmpty();
        verify(repository).findAll();
    }

    @Test
    void findAllWithTextFiltersByName() {
        when(repository.findByNameContainingIgnoreCase("lap")).thenReturn(List.of());

        assertThat(service.findAll("lap")).isEmpty();
        verify(repository).findByNameContainingIgnoreCase("lap");
    }

    @Test
    void findByIdThrowsWhenProductDoesNotExist() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findById(99L))
                .isInstanceOf(ProductNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    void createSavesTheProduct() {
        Product product = new Product("Nuevo", "desc", new BigDecimal("1.00"), 1, "hogar");
        when(repository.save(any(Product.class))).thenAnswer(i -> i.getArgument(0));

        assertThat(service.create(product).getName()).isEqualTo("Nuevo");
    }

    @Test
    void updateCopiesFieldsOntoTheExistingProduct() {
        Product existing = new Product("Viejo", "desc", new BigDecimal("1.00"), 1, "hogar");
        existing.setId(2L);
        Product changes = new Product("Nuevo", "desc nueva", new BigDecimal("9.99"), 5, "electronica");
        when(repository.findById(2L)).thenReturn(Optional.of(existing));
        when(repository.save(any(Product.class))).thenAnswer(i -> i.getArgument(0));

        Product result = service.update(2L, changes);

        assertThat(result.getName()).isEqualTo("Nuevo");
        assertThat(result.getPrice()).isEqualByComparingTo("9.99");
        assertThat(result.getId()).isEqualTo(2L);
    }
}
