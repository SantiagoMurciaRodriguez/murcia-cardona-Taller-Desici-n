# ADR-0002 · Poner el tramo nuevo en PoliticaDescuento
Variante: Q1 / fila 3

- Fecha: 2026-11-25 13:20
- Estado: aceptada

## Contexto
La Hoja 2 de Q1 agrega un tramo de descuento: si cantidad ≥ 3u (9 unidades en la fila 3), el descuento pasa a d + 5 puntos (17 %). Entre u y 3u - 1 unidades sigue siendo d (12 %) y por debajo de u sigue sin haber descuento. La muestra de la Hoja 1 solo cambia en la línea 4 (cantidad 19): pasa de 10032000 a 9462000. El cambio ya está hecho y medido con `git diff --name-status hoja-1 final`.

## Alternativas consideradas
- **Poner el tramo dentro de `PedidoUseCaseService`** — descartada porque esa clase registra el pedido y controla el stock; mezclar ahí un porcentaje de descuento es justo lo que el ADR-0001 quiso evitar al elegir hexagonal para Q1.
- **Tabla o motor configurable de tramos** — descartada porque la fila 3 tiene un solo umbral (u = 3) y un solo tramo nuevo; un motor de reglas es más código y más difícil de cambiar que una clase para una regla que el equipo comercial ajusta de vez en cuando.
- **Dos condiciones nuevas en `PoliticaDescuento.porcentaje`** — elegida.

## Decisión
El tramo se agregó en `domain/model/PoliticaDescuento.java`, con las constantes `UMBRAL_TRAMO` (3u) y `PUNTOS_TRAMO` (5) y una condición más en `porcentaje`. `total` no cambió, porque ya usa `porcentaje`. Se agregó `adapter/in/cli/MuestraHoja2Runner.java` para la muestra y `PoliticaDescuentoTramoTest.java` para el tramo, sin editar ninguna prueba de la Hoja 1. El `LEEME.md` documenta el segundo comando y avisa que la línea 4 de la Hoja 1 ahora da 9462000.

## Consecuencias
**Se gana:** el cambio cupo en una sola clase de producción del dominio, sin tocar `PedidoUseCaseService`, el adaptador web ni el de persistencia. Las pruebas de la Hoja 1 siguieron pasando sin modificarse, y la regla de arquitectura siguió verde.

**Se pierde:** `PoliticaDescuento` es ahora una clase con dos constantes y tres ramas fijas; un cuarto tramo exigiría editarla otra vez, porque no hay tabla de tramos. Y la muestra de la Hoja 1 ya no imprime lo mismo en la línea 4: sobre `hoja-1` da 10032000 y sobre `final` da 9462000.

**Veredicto sobre el ADR-0001:**
- **Predicción del costo de la Hoja 2: acertó.** Predijo 1 archivo de producción modificado (`PoliticaDescuento.java`), `LEEME.md` modificado, 2 archivos creados (`MuestraHoja2Runner.java` y `PoliticaDescuentoTramoTest.java`) y ninguna prueba de la Hoja 1 ni `PedidoUseCaseService` tocados. El diff midió 2 modificados y 2 creados, con esos mismos nombres.
- **Pérdidas declaradas en el ADR-0001:** la de la regla de dependencia se confirmó, porque se verificó con `grep` y no se cumple sola. La de los dos modelos con mapeo a mano y la de H2 contra PostgreSQL no se pusieron a prueba por este cambio. El conteo de 17 archivos nuevos no se pudo comprobar con `git diff`, porque el punto de partida y la Hoja 1 entraron en un solo commit.
- **ADR-0001 se mantiene.** Hoy se decidiría igual para Q1 / fila 3.
