# ADR-0001 · Elegir arquitectura hexagonal
Variante: Q1 / fila 3

- Fecha: 2026-11-25 12:59
- Estado: aceptada

## Contexto
La tienda vende un único producto (Monitor, $600.000, stock 24, umbral u = 3, descuento d = 12 %). El equipo comercial cambia con frecuencia las reglas de descuento (Q1), y se pide que cambiar una regla sea barato y no obligue a tocar lo que no es descuento. La Hoja 2 de Q1 ya es conocida: agrega un tramo, de modo que si cantidad ≥ 3u (9 unidades) el descuento pasa a d + 5 puntos (17 %). Hay que construir los pedidos completos, con descuento y control de stock, en unas tres horas de trabajo efectivo.

## Alternativas consideradas
- **Capas** — descartada porque, con los pedidos por escribir, el `service` que ya orquesta el stock (24 unidades) y la persistencia sería el sitio natural del descuento. El tramo nuevo de la Hoja 2 (≥ 3u) obligaría a editar una clase que también registra el pedido, justo lo que Q1 pide evitar. Con una sola regla (cantidad ≥ 3) capas alcanzaría, según la guía hexagonal; la separación depende de la disciplina y no de la estructura.
- **Monolito modular** — descartada porque su ventaja principal es la transacción única y las fronteras entre áreas de negocio (catalogo y pedidos), y esta tienda tiene un solo producto (productoId 1) y una sola regla de descuento. El único corte útil para Q1 sería aislar el descuento, y la guía advierte que un módulo mal cortado cuesta más de arreglar («decidir dónde cortar»). Se renuncia además a los pedidos ya construidos que trae esa carpeta.
- **Eventos** — descartada porque el cambio de Q1 no agrega reacciones ni consumidores: es un solo cálculo de descuento. La guía incluye «hay un solo consumidor y no habrá más» entre los casos en que alcanzan las llamadas normales. Además, con stock 24 y una muestra donde el pedido 4 (19 unidades) solo cabe si el 3 (rechazado) no consumió stock, el procesamiento asíncrono agrega consistencia eventual sin beneficio para Q1.

## Decisión
Se usa arquitectura hexagonal sobre `Arquitectura hexagonal/catalogo`. La regla de descuento y el total viven en una sola clase de dominio, `PoliticaDescuento`, sin motor de reglas. La persistencia es H2 en memoria (en lugar de PostgreSQL) para que cada arranque sea limpio; se declara aquí como decisión de la pareja. La regla de arquitectura es la mínima del enunciado: nada bajo `domain` importa `org.springframework` ni `jakarta`, y nada bajo `application` importa un `adapter`; se verifica con `grep` documentado en `LEEME.md`.

## Consecuencias
**Se gana:** la regla de descuento queda aislada del registro del pedido y de la persistencia, y se prueba sin base de datos (RN-1 y RN-2 en `PoliticaDescuentoTest`). Cambiar el descuento apunta a una sola clase.

**Se pierde:** (1) costo de construcción: hay que escribir los pedidos completos, lo que agrega 17 archivos de producción nuevos (domain, port, application, adapter) y 2 clases de prueba; esto se comprueba contando con `git diff --name-status` entre el commit inicial y `hoja-1`. (2) Dos modelos con dos mapeos a mano (`Pedido` y `PedidoJpaEntity`): si se olvida un campo, el compilador no avisa. (3) La regla de dependencia no se cumple sola: depende de la prueba o del `grep`. (4) Con H2 no se prueba contra PostgreSQL.

**Predicción del costo de la Hoja 2:** al absorber el tramo nuevo (≥ 3u → d + 5) se modifica 1 archivo de producción, `domain/model/PoliticaDescuento.java` (métodos `porcentaje` y, por tanto, el resultado de `total`); y se modifica `LEEME.md` para documentar el segundo comando. Se crean 2 archivos: `adapter/in/cli/MuestraHoja2Runner.java` (muestra de la Hoja 2) y `PoliticaDescuentoTramoTest.java` (pruebas nuevas del tramo). Se espera modificar la clase que calcula el total (`PoliticaDescuento`) y NO tocar la clase que registra el pedido (`PedidoUseCaseService`), ni `adapter/in/web`, ni `adapter/out/persistence`, ni ninguna prueba de la Hoja 1 (`PoliticaDescuentoTest` y `PedidoUseCaseServiceTest` quedan sin cambios). Si el diff muestra más de 2 archivos modificados o alguna prueba de la Hoja 1 tocada, la predicción falló.
